<?php

require('../vendor/autoload.php');

$app = new Silex\Application();
$app['debug'] = true;

// Register the monolog logging service
$app->register(new Silex\Provider\MonologServiceProvider(), array(
  'monolog.logfile' => 'php://stderr',
));



// Our web handlers

$app->get('/', function() use($app) {
  return "Hello World!!!!";
});


$app->post('/bot', function() use($app) {
	
$data=json_decode(file_get_contents("php://input"));	
	
	if(!$data){
	return "nioh";
	}
	if($data->secret != getenv("VK_SECRET_TOKEN") && $data->type!="confirmation")
	{	
	return "nioh";
	}
	switch ($data->type)
	{
	case "confirmation":
	    return getenv("VK_CONFIRM_TOKEN");
	break;
	case "message_new":
	
	$yt_api_key = "trnsl.1.1.20190122T164725Z.5c96eefd007d9360.ab4fd2d4da503b6dfca48a2bdc709c015b8e0b83";
	$yt_lang = "en-ru"; 
	
	$yt_text = $data->object->text;

$request_params = array(
	"user_id"=>$data->object->from_id,
	"random_id"=>rand(),
	"message"=>"TEST",
	"access_token"=>getenv("VK_TOKEN"),
	"v"=>'5.92'
	);

try {

    $yt_link = "https://translate.yandex.net/api/v1.5/tr.json/translate?key=".$yt_api_key."&text=".urlencode($yt_text)."&lang=".$yt_lang;
	$result = file_get_contents($yt_link);
	
	$result = json_decode($result, true); 

	$translate_text = $result['text'][0]; 

	$request_params['message']= "Translate=".$translate_text;

	} catch (\Exception $e) {
    $request_params['message']= "Wrong translate, try again!!!";
}
	file_get_contents("https://api.vk.com/method/messages.send?". http_build_query($request_params));
	
	return 'ok';
	   
	break;
	}
	
	
  return "nioh";
});

$app->run();
